package com.egao.common.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.egao.common.system.entity.Dictionary;

/**
 * 字典服务类
 * Created by wangfan on 2020-03-14 11:29:03
 */
public interface DictionaryService extends IService<Dictionary> {

}
