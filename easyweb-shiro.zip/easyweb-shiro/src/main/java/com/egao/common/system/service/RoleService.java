package com.egao.common.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.egao.common.system.entity.Role;

/**
 * 角色服务类
 * Created by wangfan on 2018-12-24 16:10
 */
public interface RoleService extends IService<Role> {

}
